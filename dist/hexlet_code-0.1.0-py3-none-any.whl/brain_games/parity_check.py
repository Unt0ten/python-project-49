from random import randint
from brain_games.cli import welcome_user


# function to determine the parity of a random number
def parity_check_game():
    tries_count = 3  # attempts counter
    while tries_count:  # number of attempts
        random_number = randint(1, 20)
        print(f'Question: {random_number}')  # question asked to the user
        user_response = input()  # user enters a response
        # determine the correct answer
        if random_number % 2 == 0:
            correct_answer = 'yes'
        else:
            correct_answer = 'no'
        if user_response == correct_answer:  # if the user answers correctly
            print('Correct!')
            tries_count -= 1  # increase response counter
            if tries_count == 0:
                print(f'Congratulations, !')
        # if the user enters the wrong answer
        else:
            print(f"'{user_response}' is wrong answer ;(. Correct answer was '{correct_answer}'. Let's try again, !")
            break
