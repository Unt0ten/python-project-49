### Hexlet tests and linter status:

[![Actions Status](https://github.com/Unt0ten/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Unt0ten/python-project-49/actions)

https://asciinema.org/a/6dDvFd8AGdtVDzQFksfmojNbi

https://asciinema.org/a/ALde2VFQxPLPyaeAq6qfcRz0t

https://asciinema.org/a/yrKZvNqDov7Z7o5vHfPlulxEX

https://asciinema.org/a/XLQvQqDiif6TroIkMLuvxENMt
