from brain_games.games.brain_prime_game import game_logic


#!/usr/bin/env python3


def main():
    game_logic()



if __name__ == '__main__':
    main()
